export class IFood {
    id :number;
    name:string;
    foodItems:string;
}